NUTRISENTIALS PROTEIN SHOP - PHONE VERSION

This is a mobile-first PWA version.

Important:
A PWA must be opened from a web address (HTTPS) to reliably install as an app.
The files can be uploaded to any HTTPS static hosting service.
Then open the address in Chrome on Android and choose:
Chrome menu (⋮) -> Add to Home screen / Install app.

The app stores its current data locally on the phone using browser storage.
